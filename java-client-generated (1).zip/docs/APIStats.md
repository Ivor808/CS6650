# APIStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**endpointStats** | [**List&lt;APIStatsEndpointStats&gt;**](APIStatsEndpointStats.md) |  |  [optional]
