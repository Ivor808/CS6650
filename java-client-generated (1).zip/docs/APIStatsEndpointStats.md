# APIStatsEndpointStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**URL** | **String** |  |  [optional]
**operation** | **String** |  |  [optional]
**mean** | **Integer** |  |  [optional]
**max** | **Integer** |  |  [optional]
