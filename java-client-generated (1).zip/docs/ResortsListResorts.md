# ResortsListResorts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resortName** | **String** |  |  [optional]
**resortID** | **Integer** |  |  [optional]
