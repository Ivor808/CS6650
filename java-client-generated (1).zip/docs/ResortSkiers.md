# ResortSkiers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**time** | **String** |  |  [optional]
**numSkiers** | **Integer** |  |  [optional]
